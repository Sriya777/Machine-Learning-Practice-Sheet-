import numpy as np
import pandas as pd
import os

class PseudoInverseModel:
    def __init__(self, data_path, sheet_name):
        try:
            data_path = data_path.strip('"')
            if not os.path.isfile(data_path):
                raise FileNotFoundError(f"The file at '{data_path}' was not found.")
        
            self.data = pd.read_excel(data_path, sheet_name=sheet_name)
            self.data = self.data[['Candies (#)', 'Mangoes (Kg)', 'Milk Packets (#)', 'Payment (Rs)']]
        except FileNotFoundError as e:
            print(str(e))
            raise
        except KeyError:
            raise Exception("Required columns are missing from the dataset.")
        except Exception as e:
            raise Exception(f"An error occurred: {str(e)}")

    def prepare_data(self):
        try:
            
            X = self.data[['Candies (#)', 'Mangoes (Kg)', 'Milk Packets (#)']].values
            X = np.hstack([np.ones((X.shape[0], 1)), X])
            y = self.data['Payment (Rs)'].values.reshape(-1, 1)
            return X, y
        except KeyError:
            raise Exception("Data preparation failed due to missing columns.")

    def compute_model_vector(self, X, y):
        try:
            X_pseudo_inverse = np.linalg.pinv(X)
            model_vector = np.dot(X_pseudo_inverse, y)
            return model_vector
        except np.linalg.LinAlgError:
            raise Exception("Linear algebra error occurred while computing the pseudo-inverse.")
        except Exception as e:
            raise Exception(f"An error occurred: {str(e)}")

    def run(self):
        try:
            X, y = self.prepare_data()
            model_vector = self.compute_model_vector(X, y)
            print("Model Vector (Cost coefficients including bias):")
            print(model_vector)
        except Exception as e:
            print(f"Error: {e}")

if __name__ == "__main__":
    print("Ensure the file path is correct and accessible.")
    file_path = input("Enter the full file path for the Excel file (e.g., C:\\path\\to\\file.xlsx): ").strip()
    sheet_name = input("Enter the sheet name: ").strip()
    
    try:
        model = PseudoInverseModel(file_path, sheet_name)
        model.run()
    except Exception as e:
        print(f"Terminated: {e}")

