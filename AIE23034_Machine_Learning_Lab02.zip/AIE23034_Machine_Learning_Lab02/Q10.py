import pandas as pd
import numpy as np
from numpy.linalg import norm
import seaborn as sns
import matplotlib.pyplot as plt


def load_data(file_path: str, sheet_name: str) -> pd.DataFrame:
    "Loading data from excel file into DataFrame"
    try:
        return pd.read_excel(file_path, sheet_name=sheet_name)
    except Exception as e:
        print(f"Error loading data: {e}")
        return pd.DataFrame()


def calculate_jaccard_coefficient(vector1: np.ndarray, vector2: np.ndarray) -> float:
    """Calculate the Jaccard Coefficient."""
    try:
        f11 = sum((vector1 == 1) & (vector2 == 1))
        f01 = sum((vector1 == 0) & (vector2 == 1))
        f10 = sum((vector1 == 1) & (vector2 == 0))
        return f11 / (f11 + f01 + f10) if (f11 + f01 + f10) != 0 else 0
    except Exception as e:
        print(f"Error calculating Jaccard Coefficient: {e}")
        return np.nan


def calculate_simple_matching_coefficient(vector1: np.ndarray, vector2: np.ndarray) -> float:
    """Calculate the Simple Matching Coefficient."""
    try:
        f11 = sum((vector1 == 1) & (vector2 == 1))
        f00 = sum((vector1 == 0) & (vector2 == 0))
        f01 = sum((vector1 == 0) & (vector2 == 1))
        f10 = sum((vector1 == 1) & (vector2 == 0))
        return (f11 + f00) / (f00 + f01 + f10 + f11) if (f00 + f01 + f10 + f11) != 0 else 0
    except Exception as e:
        print(f"Error calculating Simple Matching Coefficient: {e}")
        return np.nan


def calculate_cosine_similarity(vector1: np.ndarray, vector2: np.ndarray) -> float:
    """Calculate the Cosine Similarity."""
    try:
        dot_product = np.dot(vector1, vector2)
        magnitude = norm(vector1) * norm(vector2)
        return dot_product / magnitude if magnitude != 0 else 0
    except Exception as e:
        print(f"Error calculating Cosine Similarity: {e}")
        return np.nan


def compute_similarity_matrix(data: pd.DataFrame, similarity_function) -> pd.DataFrame:
    """Compute the similarity matrix for the given similarity function."""
    try:
        n = len(data)
        similarity_matrix = np.zeros((n, n))
        
        for i in range(n):
            for j in range(n):
                similarity_matrix[i][j] = similarity_function(data.iloc[i].values, data.iloc[j].values)

        return pd.DataFrame(similarity_matrix, index=data.index, columns=data.index)
    except Exception as e:
        print(f"Error computing similarity matrix: {e}")
        return pd.DataFrame()


def plot_heatmap(matrix: pd.DataFrame, title: str):
    """Plot a heatmap for the similarity matrix."""
    try:
        plt.figure(figsize=(10, 8))
        sns.heatmap(matrix, annot=True, cmap='coolwarm')
        plt.title(title)
        plt.show()
    except Exception as e:
        print(f"Error plotting heatmap: {e}")


def main():
    file_path = 'Lab Session Data.xlsx'
    sheet_name = 'thyroid0387_UCI'

    # Load data
    data = load_data(file_path, sheet_name)

    if data.empty:
        print("Data loading failed. Exiting...")
        return

    # Selecting the first 20 observation vectors and ensure they contain numeric data
    data = data.dropna().select_dtypes(include=['number']).iloc[:20]

    if data.shape[0] < 2:
        print("Not enough data rows for calculation. Exiting...")
        return

    # Computing and visualizing Jaccard Coefficient heatmap
    jc_matrix = compute_similarity_matrix(data, calculate_jaccard_coefficient)
    plot_heatmap(jc_matrix, "Jaccard Coefficient Heatmap")

    # Computing and visualizing Simple Matching Coefficient heatmap
    smc_matrix = compute_similarity_matrix(data, calculate_simple_matching_coefficient)
    plot_heatmap(smc_matrix, "Simple Matching Coefficient Heatmap")

    # Computing and visualizing Cosine Similarity heatmap
    cosine_matrix = compute_similarity_matrix(data, calculate_cosine_similarity)
    plot_heatmap(cosine_matrix, "Cosine Similarity Heatmap")


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"An unexpected error occurred: {e}")
