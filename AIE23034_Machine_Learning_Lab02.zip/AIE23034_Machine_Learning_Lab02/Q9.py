import pandas as pd
import numpy as np
from numpy.linalg import norm


def load_data(file_path: str, sheet_name: str) -> pd.DataFrame:
    """Load Excel data into a DataFrame."""
    try:
        return pd.read_excel(file_path, sheet_name=sheet_name)
    except Exception as e:
        print(f"Error loading data: {e}")
        return pd.DataFrame()


def calculate_cosine_similarity(vector1: np.ndarray, vector2: np.ndarray) -> float:
    """Calculate the Cosine Similarity between two vectors."""
    try:
        dot_product = np.dot(vector1, vector2)
        magnitude = norm(vector1) * norm(vector2)
        return dot_product / magnitude if magnitude != 0 else 0
    except Exception as e:
        print(f"Error calculating cosine similarity: {e}")
        return None


def main():
    file_path = 'Lab Session Data.xlsx'
    sheet_name = 'thyroid0387_UCI'

    # Load data
    data = load_data(file_path, sheet_name)

    if data.empty:
        print("Data loading failed. Exiting...")
        return

    # Ensure data does not have missing values for cosine similarity calculation
    data = data.dropna()

    if data.shape[0] < 2:
        print("Not enough data rows for calculation. Exiting...")
        return

    # Select the first two complete vectors
    vector1 = data.iloc[0].values
    vector2 = data.iloc[1].values

    print("\nFirst Vector:")
    print(vector1)
    print("\nSecond Vector:")
    print(vector2)

    # Calculate Cosine Similarity
    cosine_similarity = calculate_cosine_similarity(vector1, vector2)
    print(f"\nCosine Similarity: {cosine_similarity}")


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"An unexpected error occurred: {e}")
