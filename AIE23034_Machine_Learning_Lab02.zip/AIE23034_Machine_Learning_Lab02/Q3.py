import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import classification_report, confusion_matrix
import seaborn as sns
import matplotlib.pyplot as plt


def load_data(file_path: str, sheet_name: str) -> pd.DataFrame:
    try:
        return pd.read_excel(file_path, sheet_name=sheet_name)
    except Exception as e:
        print(f"Error loading data: {e}")
        return pd.DataFrame()


def preprocess_data(data: pd.DataFrame) -> pd.DataFrame:
    try:
        # Handle missing values
        data = data.dropna()

        # Mark customers as RICH or POOR based on Purchase Amount
        data['Customer_Class'] = data['Payment'].apply(lambda x: 'RICH' if x > 200 else 'POOR')

        # Drop non-numeric columns (except the target)
        X = data.drop(['Customer_Class', 'Customer Name'], axis=1, errors='ignore')
        y = data['Customer_Class']

        # Encode target labels
        label_encoder = LabelEncoder()
        y_encoded = label_encoder.fit_transform(y)

        return X, y_encoded, label_encoder
    except Exception as e:
        print(f"Error preprocessing data: {e}")
        return pd.DataFrame(), None, None


def train_classifier(X, y):
    try:
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

        classifier = RandomForestClassifier(random_state=42)
        classifier.fit(X_train, y_train)

        # Evaluate the model
        y_pred = classifier.predict(X_test)

        print("\nConfusion Matrix:")
        print(confusion_matrix(y_test, y_pred))

        print("\nClassification Report:")
        print(classification_report(y_test, y_pred))

        return classifier
    except Exception as e:
        print(f"Error training classifier: {e}")
        return None


def plot_feature_importance(classifier, feature_names):
    try:
        feature_importance = classifier.feature_importances_
        sns.barplot(x=feature_importance, y=feature_names)
        plt.title("Feature Importance")
        plt.show()
    except Exception as e:
        print(f"Error plotting feature importance: {e}")


def main():
    file_path = 'Lab Session Data.xlsx'
    sheet_name = 'Purchase Data'

    # Load data
    data = load_data(file_path, sheet_name)

    if data.empty:
        print("Data loading failed. Exiting...")
        return

    # Preprocess the data
    X, y, label_encoder = preprocess_data(data)

    if X.empty or y is None:
        print("Data preprocessing failed. Exiting...")
        return

    # Train classifier
    classifier = train_classifier(X, y)

    if classifier:
        plot_feature_importance(classifier, X.columns)


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"An unexpected error occurred: {e}")

