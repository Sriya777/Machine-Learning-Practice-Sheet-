import pandas as pd


def load_data(file_path: str, sheet_name: str) -> pd.DataFrame:
    """Load Excel data into a DataFrame."""
    try:
        return pd.read_excel(file_path, sheet_name=sheet_name)
    except Exception as e:
        print(f"Error loading data: {e}")
        return pd.DataFrame()


def preprocess_binary_data(data: pd.DataFrame) -> pd.DataFrame:
    """Select only binary columns for similarity measure."""
    try:
        binary_columns = [col for col in data.columns if set(data[col].dropna().unique()) <= {0, 1}]
        return data[binary_columns]
    except Exception as e:
        print(f"Error selecting binary columns: {e}")
        return pd.DataFrame()


def calculate_jaccard_coefficient(vector1, vector2):
    """Calculate the Jaccard Coefficient."""
    try:
        f11 = sum((vector1 == 1) & (vector2 == 1))
        f01 = sum((vector1 == 0) & (vector2 == 1))
        f10 = sum((vector1 == 1) & (vector2 == 0))
        return f11 / (f11 + f01 + f10) if (f11 + f01 + f10) != 0 else 0
    except Exception as e:
        print(f"Error calculating Jaccard Coefficient: {e}")
        return None


def calculate_simple_matching_coefficient(vector1, vector2):
    """Calculate the Simple Matching Coefficient."""
    try:
        f11 = sum((vector1 == 1) & (vector2 == 1))
        f00 = sum((vector1 == 0) & (vector2 == 0))
        f01 = sum((vector1 == 0) & (vector2 == 1))
        f10 = sum((vector1 == 1) & (vector2 == 0))
        return (f11 + f00) / (f00 + f01 + f10 + f11) if (f00 + f01 + f10 + f11) != 0 else 0
    except Exception as e:
        print(f"Error calculating Simple Matching Coefficient: {e}")
        return None


def main():
    file_path = 'Lab Session Data.xlsx'
    sheet_name = 'thyroid0387_UCI'

    # Load data
    data = load_data(file_path, sheet_name)

    if data.empty:
        print("Data loading failed. Exiting...")
        return

    # Preprocess binary data
    binary_data = preprocess_binary_data(data)

    if binary_data.shape[0] < 2:
        print("Not enough binary rows for calculation. Exiting...")
        return

    # Select the first two binary vectors
    vector1 = binary_data.iloc[0]
    vector2 = binary_data.iloc[1]

    print("\nFirst Vector:")
    print(vector1)
    print("\nSecond Vector:")
    print(vector2)

    # Calculate Jaccard Coefficient
    jaccard_coefficient = calculate_jaccard_coefficient(vector1, vector2)
    print(f"\nJaccard Coefficient: {jaccard_coefficient}")

    # Calculate Simple Matching Coefficient
    simple_matching_coefficient = calculate_simple_matching_coefficient(vector1, vector2)
    print(f"Simple Matching Coefficient: {simple_matching_coefficient}")


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"An unexpected error occurred: {e}")
