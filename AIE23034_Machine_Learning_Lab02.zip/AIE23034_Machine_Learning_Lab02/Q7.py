import pandas as pd
from sklearn.preprocessing import MinMaxScaler, StandardScaler


def load_data(file_path: str, sheet_name: str) -> pd.DataFrame:
    """Load Excel data into a DataFrame."""
    try:
        return pd.read_excel(file_path, sheet_name=sheet_name)
    except Exception as e:
        print(f"Error loading data: {e}")
        return pd.DataFrame()


def identify_attributes_for_scaling(data: pd.DataFrame):
    """Identify numeric attributes for scaling."""
    try:
        numeric_columns = data.select_dtypes(include=['number']).columns
        print("\nNumeric attributes identified for scaling:")
        print(numeric_columns)
        return numeric_columns
    except Exception as e:
        print(f"Error identifying attributes for scaling: {e}")
        return []


def apply_min_max_scaling(data: pd.DataFrame, columns: list) -> pd.DataFrame:
    """Apply Min-Max scaling to selected attributes."""
    try:
        scaler = MinMaxScaler()
        data[columns] = scaler.fit_transform(data[columns])
        print("\nMin-Max Scaling applied.")
    except Exception as e:
        print(f"Error applying Min-Max scaling: {e}")
    return data


def apply_standard_scaling(data: pd.DataFrame, columns: list) -> pd.DataFrame:
    """Apply Standard scaling (Z-score) to selected attributes."""
    try:
        scaler = StandardScaler()
        data[columns] = scaler.fit_transform(data[columns])
        print("\nStandard Scaling applied.")
    except Exception as e:
        print(f"Error applying Standard scaling: {e}")
    return data


def main():
    file_path = 'Lab Session Data.xlsx'
    sheet_name = 'thyroid0387_UCI'

    # Load the data
    data = load_data(file_path, sheet_name)

    if data.empty:
        print("Data loading failed. Exiting...")
        return

    # Identify numeric attributes for scaling
    numeric_columns = identify_attributes_for_scaling(data)

    # Display original statistics
    print("\nOriginal Data Statistics:")
    print(data[numeric_columns].describe())

    # Min-Max Scaling
    scaled_data_min_max = apply_min_max_scaling(data.copy(), numeric_columns)
    print("\nData after Min-Max Scaling:")
    print(scaled_data_min_max[numeric_columns].head())

    # Standard Scaling
    scaled_data_standard = apply_standard_scaling(data.copy(), numeric_columns)
    print("\nData after Standard Scaling:")
    print(scaled_data_standard[numeric_columns].head())


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"An unexpected error occurred: {e}")
