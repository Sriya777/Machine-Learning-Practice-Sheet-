import pandas as pd
import numpy as np

def load_data(file_path: str, sheet_name: str) -> pd.DataFrame:
    
    try:
        return pd.read_excel(file_path, sheet_name=sheet_name)
    except FileNotFoundError:
        print("Error: File not found.")
        raise
    except ValueError:
        print("Error: Invalid sheet name.")
        raise


def clean_data(data: pd.DataFrame) -> pd.DataFrame:
    try:
        return data[['Candies (#)', 'Mangoes (Kg)', 'Milk Packets (#)', 'Payment (Rs)']].dropna()
    except KeyError as e:
        print(f"Error: Missing expected columns - {e}")
        raise


def compute_matrices(cleaned_data: pd.DataFrame):
    A = cleaned_data[['Candies (#)', 'Mangoes (Kg)', 'Milk Packets (#)']].values
    C = cleaned_data[['Payment (Rs)']].values
    return A, C


def compute_vector_space_properties(A: np.ndarray):
    dimensionality = A.shape[1]
    num_vectors = A.shape[0]
    rank_A = np.linalg.matrix_rank(A)
    return dimensionality, num_vectors, rank_A


def compute_costs(A: np.ndarray, C: np.ndarray):
    try:
        cost_vector = np.linalg.pinv(A) @ C
        return cost_vector
    except np.linalg.LinAlgError as e:
        print("Error: Failed to compute pseudo-inverse.")
        raise


def display_results(dimensionality, num_vectors, rank_A, cost_vector):
    print(f"Dimensionality of the vector space: {dimensionality}")
    print(f"Number of vectors in the vector space: {num_vectors}")
    print(f"Rank of Matrix A: {rank_A}")
    print("Cost of each product:")
    print(f"Candies: ₹{cost_vector[0][0]:.2f} per unit")
    print(f"Mangoes: ₹{cost_vector[1][0]:.2f} per kg")
    print(f"Milk Packets: ₹{cost_vector[2][0]:.2f} per unit")


def main():
    file_path = 'Lab Session Data.xlsx'
    sheet_name = 'Purchase data'

    try:
        # Load and process data
        data = load_data(file_path, sheet_name)
        cleaned_data = clean_data(data)
        A, C = compute_matrices(cleaned_data)

        # Compute properties and costs
        dimensionality, num_vectors, rank_A = compute_vector_space_properties(A)
        cost_vector = compute_costs(A, C)

        # Display results
        display_results(dimensionality, num_vectors, rank_A, cost_vector)
    except Exception as e:
        print(f"An error occurred: {e}")


if __name__ == '__main__':
    main()
