import pandas as pd
import numpy as np


def load_data(file_path: str, sheet_name: str) -> pd.DataFrame:
    try:
        return pd.read_excel(file_path, sheet_name=sheet_name)
    except Exception as e:
        print(f"Error loading data: {e}")
        return pd.DataFrame()


def explore_data(data: pd.DataFrame):
    try:
        print("Dataset Information:")
        print(data.info())
        print("\nFirst 5 Rows:")
        print(data.head())
    except Exception as e:
        print(f"Error during data exploration: {e}")


def identify_data_types(data: pd.DataFrame):
    try:
        print("\nData Types for Attributes:")
        for column in data.columns:
            unique_values = data[column].unique()
            data_type = "Numeric" if np.issubdtype(data[column].dtype, np.number) else "Categorical"
            print(f"{column}: {data_type} - Unique Values Sample: {unique_values[:5]}")
    except Exception as e:
        print(f"Error identifying data types: {e}")


def check_missing_values(data: pd.DataFrame):
    try:
        print("\nMissing Values by Attribute:")
        print(data.isnull().sum())
    except Exception as e:
        print(f"Error checking missing values: {e}")


def check_data_ranges(data: pd.DataFrame):
    try:
        print("\nData Ranges for Numeric Attributes:")
        for column in data.select_dtypes(include=[np.number]).columns:
            print(f"{column}: Min={data[column].min()}, Max={data[column].max()}")
    except Exception as e:
        print(f"Error checking data ranges: {e}")


def detect_outliers(data: pd.DataFrame):
    try:
        print("\nOutliers in Numeric Attributes:")
        for column in data.select_dtypes(include=[np.number]).columns:
            q1 = data[column].quantile(0.25)
            q3 = data[column].quantile(0.75)
            iqr = q3 - q1
            lower_bound = q1 - 1.5 * iqr
            upper_bound = q3 + 1.5 * iqr
            outliers = data[(data[column] < lower_bound) | (data[column] > upper_bound)][column]
            print(f"{column}: {len(outliers)} potential outliers")
    except Exception as e:
        print(f"Error detecting outliers: {e}")


def calculate_statistics(data: pd.DataFrame):
    try:
        print("\nMean and Variance for Numeric Attributes:")
        for column in data.select_dtypes(include=[np.number]).columns:
            mean_val = data[column].mean()
            variance_val = data[column].var()
            print(f"{column}: Mean={mean_val}, Variance={variance_val}")
    except Exception as e:
        print(f"Error calculating statistics: {e}")


def main():
    file_path = 'Lab Session Data.xlsx'
    sheet_name = 'thyroid0387_UCI'

    # Load data
    data = load_data(file_path, sheet_name)

    if data.empty:
        print("Data loading failed. Exiting...")
        return

    explore_data(data)
    identify_data_types(data)
    check_missing_values(data)
    check_data_ranges(data)
    detect_outliers(data)
    calculate_statistics(data)


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"An unexpected error occurred: {e}")
