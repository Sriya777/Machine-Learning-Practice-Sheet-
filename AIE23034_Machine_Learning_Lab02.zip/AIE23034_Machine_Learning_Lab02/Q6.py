import pandas as pd
import numpy as np


def load_data(file_path: str, sheet_name: str) -> pd.DataFrame:
    try:
        return pd.read_excel(file_path, sheet_name=sheet_name)
    except Exception as e:
        print(f"Error loading data: {e}")
        return pd.DataFrame()


def impute_missing_values(data: pd.DataFrame) -> pd.DataFrame:
    try:
        for column in data.columns:
            if data[column].isnull().sum() > 0:
                if np.issubdtype(data[column].dtype, np.number):
                    if is_outlier_present(data[column]):
                        imputed_value = data[column].median()
                        print(f"Imputing median for {column} due to outliers.")
                    else:
                        imputed_value = data[column].mean()
                        print(f"Imputing mean for {column}.")
                else:
                    imputed_value = data[column].mode()[0]
                    print(f"Imputing mode for {column}.")
                
                # Impute the missing values
                data[column].fillna(imputed_value, inplace=True)
    except Exception as e:
        print(f"Error during data imputation: {e}")

    return data


def is_outlier_present(series: pd.Series) -> bool:
    try:
        q1 = series.quantile(0.25)
        q3 = series.quantile(0.75)
        iqr = q3 - q1
        lower_bound = q1 - 1.5 * iqr
        upper_bound = q3 + 1.5 * iqr
        return ((series < lower_bound) | (series > upper_bound)).any()
    except Exception as e:
        print(f"Error detecting outliers: {e}")
        return False


def main():
    file_path = 'Lab Session Data.xlsx'
    sheet_name = 'thyroid0387_UCI'

    data = load_data(file_path, sheet_name)

    if data.empty:
        print("Data loading failed. Exiting...")
        return

    print("\nMissing Values Before Imputation:")
    print(data.isnull().sum())

    
    imputed_data = impute_missing_values(data)

    
    print("\nMissing Values After Imputation:")
    print(imputed_data.isnull().sum())


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"An unexpected error occurred: {e}")
