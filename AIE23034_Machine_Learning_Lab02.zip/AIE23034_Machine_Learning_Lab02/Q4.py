import pandas as pd
import statistics as stats
import matplotlib.pyplot as plt


def load_data(file_path: str, sheet_name: str) -> pd.DataFrame:
   
    return pd.read_excel(file_path, sheet_name=sheet_name)


def calculate_mean_and_variance(price_data: pd.Series) -> tuple:
    
    mean_price = stats.mean(price_data)
    variance_price = stats.variance(price_data)
    return mean_price, variance_price


def sample_mean_for_day(data: pd.DataFrame, day_name: str) -> float:
    sample_prices = data[data['Day'] == day_name]['Price']
    return stats.mean(sample_prices) if not sample_prices.empty else None


def sample_mean_for_month(data: pd.DataFrame, month: int) -> float:
    sample_prices = data[data['Date'].dt.month == month]['Price']
    return stats.mean(sample_prices) if not sample_prices.empty else None


def probability_of_loss(chg_data: pd.Series) -> float:
    return sum(map(lambda x: x < 0, chg_data)) / len(chg_data)


def probability_of_profit_on_day(data: pd.DataFrame, day_name: str) -> float:
    day_chg = data[data['Day'] == day_name]['Chg%']
    return sum(day_chg > 0) / len(day_chg) if not day_chg.empty else 0


def conditional_probability_profit_given_day(data: pd.DataFrame, day_name: str) -> float:
    day_chg = data[data['Day'] == day_name]['Chg%']
    return sum(day_chg > 0) / len(data['Chg%']) if not data.empty else 0


def scatter_plot_chg_vs_day(data: pd.DataFrame):
    plt.figure(figsize=(10, 5))
    plt.scatter(data['Day'], data['Chg%'], color='blue')
    plt.title('Chg% vs Day of the Week')
    plt.xlabel('Day of the Week')
    plt.ylabel('Chg%')
    plt.xticks(rotation=45)
    plt.grid(True)
    plt.show()


def main():
    
    file_path = 'Lab Session Data.xlsx'
    sheet_name = 'IRCTC Stock Price'
    data = load_data(file_path, sheet_name)

    
    data['Date'] = pd.to_datetime(data['Date'])
    data['Day'] = data['Date'].dt.day_name()

    
    mean_price, variance_price = calculate_mean_and_variance(data['Price'])
    print(f"Mean Price: {mean_price}")
    print(f"Variance of Price: {variance_price}")

  
    mean_wednesday_price = sample_mean_for_day(data, 'Wednesday')
    print(f"Mean Wednesday Price: {mean_wednesday_price}")

  
    mean_april_price = sample_mean_for_month(data, 4)
    print(f"Mean April Price: {mean_april_price}")

 
    loss_prob = probability_of_loss(data['Chg%'])
    print(f"Probability of making a loss: {loss_prob}")

    
    wednesday_profit_prob = probability_of_profit_on_day(data, 'Wednesday')
    print(f"Probability of profit on Wednesday: {wednesday_profit_prob}")

    
    conditional_profit_prob = conditional_probability_profit_given_day(data, 'Wednesday')
    print(f"Conditional probability of profit given it's Wednesday: {conditional_profit_prob}")

 
    scatter_plot_chg_vs_day(data)


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"An error occurred: {e}")

