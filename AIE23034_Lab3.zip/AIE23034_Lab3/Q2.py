# A2: Histogram for a selected feature and density analysis
import pandas as pd
import matplotlib.pyplot as plt

# Load the dataset
df = pd.read_excel(r"C:\Users\Sriya Nistala\Downloads\AIE23034_Lab3\20230409_playback_data_for_upload.xlsx")

# Select numeric columns for analysis
numeric_columns = ["Distance", "dBC", "dBZ", "Playback", "NumVocPre", "NumVocPost", "DurVigPre"]

# Drop rows with missing values
df = df[numeric_columns].dropna()

# Plot histogram for a selected feature
feature = "Distance"
plt.hist(df[feature], bins=10, color='skyblue')
plt.title(f"Histogram of {feature}")
plt.xlabel(feature)
plt.ylabel("Frequency")
plt.show()

# Calculate mean and variance
mean_value = df[feature].mean()
variance_value = df[feature].var()

print(f"Mean of {feature}: {mean_value}")
print(f"Variance of {feature}: {variance_value}")