import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score

# Load dataset
df = pd.read_excel(r"C:\Users\Sriya Nistala\Downloads\AIE23034_Lab3\20230409_playback_data_for_upload.xlsx")
df = df.select_dtypes(include=[np.number]).dropna()

# Split features and target
X = df.drop(columns=['Order60'])
y = df['Order60']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Scale data
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Evaluate accuracy for different k values
k_values = range(1, 12)
accuracies = []

for k in k_values:
    model = KNeighborsClassifier(n_neighbors=k)
    model.fit(X_train_scaled, y_train)
    y_pred = model.predict(X_test_scaled)
    accuracies.append(accuracy_score(y_test, y_pred))

# Plot accuracy
plt.plot(k_values, accuracies, marker='o')
plt.xlabel('Number of Neighbors (k)')
plt.ylabel('Accuracy')
plt.title('kNN Accuracy for Different k Values')
plt.show()

# Compare NN (k=1) with kNN (k=3)
k1_model = KNeighborsClassifier(n_neighbors=1)
k1_model.fit(X_train_scaled, y_train)
k1_accuracy = accuracy_score(y_test, k1_model.predict(X_test_scaled))

k3_model = KNeighborsClassifier(n_neighbors=3)
k3_model.fit(X_train_scaled, y_train)
k3_accuracy = accuracy_score(y_test, k3_model.predict(X_test_scaled))

print(f"Accuracy with k=1 (NN): {k1_accuracy}")
print(f"Accuracy with k=3 (kNN): {k3_accuracy}")