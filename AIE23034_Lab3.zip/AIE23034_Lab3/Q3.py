# A3: Minkowski distance calculation for two feature vectors
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# Load the dataset
df = pd.read_excel(r"C:\Users\Sriya Nistala\Downloads\AIE23034_Lab3\20230409_playback_data_for_upload.xlsx")

# Select numeric columns for analysis
numeric_columns = ["Distance", "dBC", "dBZ", "Playback", "NumVocPre", "NumVocPost", "DurVigPre"]

# Drop rows with missing values
df = df[numeric_columns].dropna()

# Select two feature vectors for distance calculation
vector1 = df.iloc[0].values
vector2 = df.iloc[1].values

# Calculate Minkowski distances for r from 1 to 10
distances = []
r_values = range(1, 11)

for r in r_values:
    distance = np.linalg.norm(vector1 - vector2, ord=r)
    distances.append(distance)

# Plot Minkowski distances
plt.plot(r_values, distances, marker='o')
plt.title("Minkowski Distance between Two Feature Vectors")
plt.xlabel("Order r")
plt.ylabel("Distance")
plt.grid(True)
plt.show()

print("Minkowski distances for r from 1 to 10:", distances)
