import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier

# Load dataset
df = pd.read_excel('20230409_playback_data_for_upload.xlsx', sheet_name='20230409_playback_data_for_uplo')
df = df.select_dtypes(include=[np.number]).dropna()

# Split features and target
X = df.drop(columns=['Order60'])
y = df['Order60']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Scale data
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Train classifier
k = 3  # Default k value for kNN
model = KNeighborsClassifier(n_neighbors=k)
model.fit(X_train_scaled, y_train)

# Predict and analyze behavior
y_test_pred = model.predict(X_test_scaled)

print("Predictions for test data:", y_test_pred)

# Perform classification on a single test vector
test_vect = X_test_scaled[0].reshape(1, -1)  # Selecting a single test vector
predicted_class = model.predict(test_vect)
print(f"Predicted class for test vector {test_vect}: {predicted_class[0]}")