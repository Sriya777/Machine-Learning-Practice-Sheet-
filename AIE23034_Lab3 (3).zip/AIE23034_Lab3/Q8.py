import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score

def load_data(file_path):
    """Load the dataset from an Excel file."""
    try:
        df = pd.read_excel(file_path)
        return df
    except Exception as e:
        print(f"Error loading data: {e}")
        return None

def select_numeric_columns(df):
    """Select numeric columns from the dataframe."""
    return df.select_dtypes(include=[np.number]).dropna()

def split_features_target(df, target_column):
    """Split the dataset into features and target."""
    X = df.drop(columns=[target_column])
    y = df[target_column]
    return X, y

def scale_data(X_train, X_test):
    """Scale the training and test data."""
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    return X_train_scaled, X_test_scaled

def evaluate_knn_accuracy(X_train, y_train, X_test, y_test, k_values):
    """Evaluate accuracy for different k values."""
    accuracies = []
    for k in k_values:
        model = KNeighborsClassifier(n_neighbors=k)
        model.fit(X_train, y_train)
        y_pred = model.predict(X_test)
        accuracies.append(accuracy_score(y_test, y_pred))
    return accuracies

def compare_knn_models(X_train, y_train, X_test, y_test):
    """Compare kNN models with k=1 and k=3."""
    k1_model = KNeighborsClassifier(n_neighbors=1)
    k1_model.fit(X_train, y_train)
    k1_accuracy = accuracy_score(y_test, k1_model.predict(X_test))

    k3_model = KNeighborsClassifier(n_neighbors=3)
    k3_model.fit(X_train, y_train)
    k3_accuracy = accuracy_score(y_test, k3_model.predict(X_test))

    return k1_accuracy, k3_accuracy

# Main execution
if __name__ == "__main__":
    df = load_data(r"C:\Users\Sriya Nistala\Downloads\AIE23034_Lab3\20230409_playback_data_for_upload.xlsx")
    if df is not None:
        df_numeric = select_numeric_columns(df)
        X, y = split_features_target(df_numeric, 'Order60')
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        X_train_scaled, X_test_scaled = scale_data(X_train, X_test)

        k_values = range(1, 12)
        accuracies = evaluate_knn_accuracy(X_train_scaled, y_train, X_test_scaled, y_test, k_values)

        # Plot accuracy
        plt.plot(k_values, accuracies, marker='o')
        plt.xlabel('Number of Neighbors (k)')
        plt.ylabel('Accuracy')
        plt.title('kNN Accuracy for Different k Values')
        plt.show()

        k1_accuracy, k3_accuracy = compare_knn_models(X_train_scaled, y_train, X_test_scaled, y_test)
        print(f"Accuracy with k=1 (NN): {k1_accuracy}")
        print(f"Accuracy with k=3 (kNN): {k3_accuracy}")
