import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier

def load_data(file_path):
    """Load the dataset from an Excel file."""
    try:
        df = pd.read_excel(file_path)
        return df
    except Exception as e:
        print(f"Error loading data: {e}")
        return None

def select_numeric_columns(df, columns):
    """Select numeric columns from the dataframe."""
    return df[columns].dropna()

def split_dataset(df, target_column):
    """Split the dataset into features and target."""
    X = df.drop(target_column, axis=1)  # Features
    y = (df[target_column] > 0).astype(int)  # Binary target
    return X, y

def train_knn_classifier(X_train, y_train, k=3):
    """Train a kNN classifier."""
    knn = KNeighborsClassifier(n_neighbors=k)
    knn.fit(X_train, y_train)
    return knn

def test_knn_accuracy(knn, X_test, y_test):
    """Test the accuracy of the kNN classifier."""
    accuracy = knn.score(X_test, y_test)
    return accuracy

# Main execution
if __name__ == "__main__":
    df = load_data(r"C:\Users\Sriya Nistala\Downloads\AIE23034_Lab3\20230409_playback_data_for_upload.xlsx")
    if df is not None:
        numeric_columns = ["Distance", "dBC", "dBZ", "Playback", "NumVocPre", "NumVocPost", "DurVigPre"]
        df_numeric = select_numeric_columns(df, numeric_columns)
        
        X, y = split_dataset(df_numeric, "NumVocPre")
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)
        
        knn_model = train_knn_classifier(X_train, y_train, k=3)
        accuracy = test_knn_accuracy(knn_model, X_test, y_test)
        print("kNN classifier accuracy on test set:", accuracy)
