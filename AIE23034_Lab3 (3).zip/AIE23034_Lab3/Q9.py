import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report


def load_data(file_path):
    """Load the dataset from an Excel file."""
    try:
        df = pd.read_excel(file_path)
        return df
    except Exception as e:
        print(f"Error loading data: {e}")
        return None

def select_numeric_columns(df):
    """Select numeric columns from the dataframe."""
    return df.select_dtypes(include=[np.number]).dropna()

def split_features_target(df, target_column):
    """Split the dataset into features and target."""
    X = df.drop(columns=[target_column])
    y = df[target_column]
    return X, y

def scale_data(X_train, X_test):
    """Scale the training and test data."""
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    return X_train_scaled, X_test_scaled

def train_knn_classifier(X_train, y_train, k=3):
    """Train a kNN classifier."""
    model = KNeighborsClassifier(n_neighbors=k)
    model.fit(X_train, y_train)
    return model

def evaluate_model(model, X_train, y_train, X_test, y_test):
    """Evaluate the model and print performance metrics."""
    y_train_pred = model.predict(X_train)
    y_test_pred = model.predict(X_test)

    conf_matrix_train = confusion_matrix(y_train, y_train_pred)
    conf_matrix_test = confusion_matrix(y_test, y_test_pred)

    print("Confusion Matrix (Training Data):\n", conf_matrix_train)
    print("Confusion Matrix (Test Data):\n", conf_matrix_test)

    print("Classification Report (Training Data):\n", classification_report(y_train, y_train_pred))
    print("Classification Report (Test Data):\n", classification_report(y_test, y_test_pred))

    train_accuracy = accuracy_score(y_train, y_train_pred)
    test_accuracy = accuracy_score(y_test, y_test_pred)

    print(f"Training Accuracy: {train_accuracy}")
    print(f"Test Accuracy: {test_accuracy}")

    if train_accuracy > test_accuracy + 0.1:
        print("Model is overfitting.")
    elif test_accuracy > train_accuracy:
        print("Model might be underfitting.")
    else:
        print("Model is well-generalized (regular fit).")

# Main execution
if __name__ == "__main__":
    df = load_data(r"C:\Users\Sriya Nistala\Downloads\AIE23034_Lab3\20230409_playback_data_for_upload.xlsx")
    if df is not None:
        df_numeric = select_numeric_columns(df)
        X, y = split_features_target(df_numeric, 'Order60')
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        X_train_scaled, X_test_scaled = scale_data(X_train, X_test)

        knn_model = train_knn_classifier(X_train_scaled, y_train, k=3)
        evaluate_model(knn_model, X_train_scaled, y_train, X_test_scaled, y_test)
