import pandas as pd
from sklearn.model_selection import train_test_split

def load_data(file_path):
    """Load the dataset from an Excel file."""
    try:
        df = pd.read_excel(file_path)
        return df
    except Exception as e:
        print(f"Error loading data: {e}")
        return None

def select_numeric_columns(df, columns):
    """Select numeric columns from the dataframe."""
    return df[columns].dropna()

def split_dataset(df, target_column, test_size=0.3):
    """Split the dataset into training and test sets."""
    X = df.drop(target_column, axis=1)  # Features
    y = (df[target_column] > 0).astype(int)  # Binary target
    return train_test_split(X, y, test_size=test_size, random_state=42)

# Main execution
if __name__ == "__main__":
    df = load_data(r"C:\Users\Sriya Nistala\Downloads\AIE23034_Lab3\20230409_playback_data_for_upload.xlsx")
    if df is not None:
        numeric_columns = ["Distance", "dBC", "dBZ", "Playback", "NumVocPre", "NumVocPost", "DurVigPre"]
        df_numeric = select_numeric_columns(df, numeric_columns)
        
        X_train, X_test, y_train, y_test = split_dataset(df_numeric, "NumVocPre")
        
        print("Training set size:", X_train.shape)
        print("Test set size:", X_test.shape)
