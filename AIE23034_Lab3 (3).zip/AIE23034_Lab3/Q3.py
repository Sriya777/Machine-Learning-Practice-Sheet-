import numpy as np
import pandas as pd
import matplotlib.pyplot as plt



def load_data(file_path):
    """Load the dataset from an Excel file."""
    try:
        df = pd.read_excel(file_path)
        return df
    except Exception as e:
        print(f"Error loading data: {e}")
        return None

def select_numeric_columns(df, columns):
    """Select numeric columns from the dataframe."""
    return df[columns].dropna()

def calculate_minkowski_distances(vector1, vector2, r_values):
    """Calculate Minkowski distances for given vectors and r values."""
    distances = []
    for r in r_values:
        distance = np.linalg.norm(vector1 - vector2, ord=r)
        distances.append(distance)
    return distances

def plot_distances(r_values, distances):
    """Plot Minkowski distances."""
    plt.plot(r_values, distances, marker='o')
    plt.title("Minkowski Distance between Two Feature Vectors")
    plt.xlabel("Order r")
    plt.ylabel("Distance")
    plt.grid(True)
    plt.show()

# Main execution
if __name__ == "__main__":
    df = load_data(r"C:\Users\Sriya Nistala\Downloads\AIE23034_Lab3\20230409_playback_data_for_upload.xlsx")
    if df is not None:
        numeric_columns = ["Distance", "dBC", "dBZ", "Playback", "NumVocPre", "NumVocPost", "DurVigPre"]
        df_numeric = select_numeric_columns(df, numeric_columns)

        vector1 = df_numeric.iloc[0].values
        vector2 = df_numeric.iloc[1].values
        r_values = range(1, 11)

        distances = calculate_minkowski_distances(vector1, vector2, r_values)
        plot_distances(r_values, distances)

        print("Minkowski distances for r from 1 to 10:", distances)
