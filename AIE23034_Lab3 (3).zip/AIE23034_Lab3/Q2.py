import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split

def load_data(file_path):
    """Load the dataset from an Excel file."""
    try:
        df = pd.read_excel(file_path)
        return df
    except Exception as e:
        print(f"Error loading data: {e}")
        return None

def select_numeric_columns(df, columns):
    """Select numeric columns from the dataframe."""
    return df[columns].dropna()

def plot_histogram(data, feature):
    """Plot histogram for a selected feature."""
    plt.hist(data[feature], bins=10, color='skyblue')
    plt.title(f"Histogram of {feature}")
    plt.xlabel(feature)
    plt.ylabel("Frequency")
    plt.show()

def calculate_statistics(data, feature):
    """Calculate mean and variance of a feature."""
    mean_value = data[feature].mean()
    variance_value = data[feature].var()
    return mean_value, variance_value

# Main execution
if __name__ == "__main__":
    df = load_data(r"C:\Users\Sriya Nistala\Downloads\AIE23034_Lab3\20230409_playback_data_for_upload.xlsx")
    if df is not None:
        numeric_columns = ["Distance", "dBC", "dBZ", "Playback", "NumVocPre", "NumVocPost", "DurVigPre"]
        df_numeric = select_numeric_columns(df, numeric_columns)
        
        feature = "Distance"
        plot_histogram(df_numeric, feature)
        
        mean_value, variance_value = calculate_statistics(df_numeric, feature)
        print(f"Mean of {feature}: {mean_value}")
        print(f"Variance of {feature}: {variance_value}")
