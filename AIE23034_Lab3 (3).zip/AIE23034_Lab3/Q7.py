import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier


def load_data(file_path):
    """Load the dataset from an Excel file."""
    try:
        df = pd.read_excel(file_path)
        return df
    except Exception as e:
        print(f"Error loading data: {e}")
        return None

def select_numeric_columns(df):
    """Select numeric columns from the dataframe."""
    return df.select_dtypes(include=[np.number]).dropna()

def split_features_target(df, target_column):
    """Split the dataset into features and target."""
    X = df.drop(columns=[target_column])
    y = df[target_column]
    return X, y

def scale_data(X_train, X_test):
    """Scale the training and test data."""
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    return X_train_scaled, X_test_scaled

def train_knn_classifier(X_train, y_train, k=3):
    """Train a kNN classifier."""
    model = KNeighborsClassifier(n_neighbors=k)
    model.fit(X_train, y_train)
    return model

def predict(model, X):
    """Make predictions using the trained model."""
    return model.predict(X)

# Main execution
if __name__ == "__main__":
    df = load_data(r"C:\Users\Sriya Nistala\Downloads\AIE23034_Lab3\20230409_playback_data_for_upload.xlsx")
    if df is not None:
        df_numeric = select_numeric_columns(df)
        X, y = split_features_target(df_numeric, 'Order300')
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        X_train_scaled, X_test_scaled = scale_data(X_train, X_test)
        
        knn_model = train_knn_classifier(X_train_scaled, y_train, k=3)
        y_test_pred = predict(knn_model, X_test_scaled)
        
        print("Predictions for test data:", y_test_pred)

        # Perform classification on a single test vector
        test_vect = X_test_scaled[0].reshape(1, -1)  # Selecting a single test vector
        predicted_class = predict(knn_model, test_vect)
        print(f"Predicted class for test vector {test_vect}: {predicted_class[0]}")
